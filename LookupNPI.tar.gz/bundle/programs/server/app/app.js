var require = meteorInstall({"imports":{"Results.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// imports/Results.js                                                          //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.export({                                                                // 1
  Results: function () {                                                       // 1
    return Results;                                                            // 1
  }                                                                            // 1
});                                                                            // 1
var Mongo = void 0;                                                            // 1
module.watch(require("meteor/mongo"), {                                        // 1
  Mongo: function (v) {                                                        // 1
    Mongo = v;                                                                 // 1
  }                                                                            // 1
}, 0);                                                                         // 1
var Results = new Mongo.Collection('results');                                 // 4
/////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// server/main.js                                                              //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
var Meteor = void 0;                                                           // 1
module.watch(require("meteor/meteor"), {                                       // 1
    Meteor: function (v) {                                                     // 1
        Meteor = v;                                                            // 1
    }                                                                          // 1
}, 0);                                                                         // 1
var Mongo = void 0;                                                            // 1
module.watch(require("meteor/mongo"), {                                        // 1
    Mongo: function (v) {                                                      // 1
        Mongo = v;                                                             // 1
    }                                                                          // 1
}, 1);                                                                         // 1
var Session = void 0;                                                          // 1
module.watch(require("meteor/session"), {                                      // 1
    Session: function (v) {                                                    // 1
        Session = v;                                                           // 1
    }                                                                          // 1
}, 2);                                                                         // 1
var Results = void 0;                                                          // 1
module.watch(require("../imports/Results"), {                                  // 1
    Results: function (v) {                                                    // 1
        Results = v;                                                           // 1
    }                                                                          // 1
}, 3);                                                                         // 1
Meteor.startup(function () {// code to run on server at startup                // 6
});                                                                            // 8
Meteor.methods({                                                               // 10
    NumberSearch: function (number) {                                          // 11
        npiresult = HTTP.call('GET', 'https://npiregistry.cms.hhs.gov/api', {  // 12
            params: {                                                          // 14
                'number': number                                               // 15
            }                                                                  // 14
        }).data; // console.dir(result)                                        // 13
                                                                               //
        Meteor.call('clearNPIResults');                                        // 19
        Results.insert({                                                       // 20
            type: 'npi',                                                       // 21
            result: npiresult                                                  // 22
        }); // inserts new results into db for display.                        // 20
    },                                                                         // 24
    nameSearch: function (first, last) {                                       // 27
        nameresult = HTTP.call('GET', 'https://npiregistry.cms.hhs.gov/api', {
            params: {                                                          // 30
                'first_name': first,                                           // 31
                'last_name': last                                              // 32
            }                                                                  // 30
        }).data;                                                               // 29
        Meteor.call('clearNameResults');                                       // 35
        console.dir(nameresult);                                               // 36
        Results.insert({                                                       // 37
            type: 'name',                                                      // 38
            result: nameresult                                                 // 39
        });                                                                    // 37
    },                                                                         // 42
    clearNPIResults: function () {                                             // 45
        console.log('npi result supposed to be cleared');                      // 46
        Results.remove({                                                       // 47
            type: 'npi'                                                        // 47
        }); // Remove any prior NPI results. this is run on browser startup.   // 47
    },                                                                         // 48
    clearNameResults: function () {                                            // 49
        Results.remove({                                                       // 50
            type: 'name'                                                       // 50
        }); // Remove any prior Name results. this is run on browser startup.  // 50
    },                                                                         // 51
    clearResults: function () {                                                // 52
        Results.remove({});                                                    // 53
    },                                                                         // 54
    NpiSearchFromClick: function (number) {                                    // 56
        console.log(number);                                                   // 57
    }                                                                          // 58
});                                                                            // 10
/////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/main.js");
//# sourceMappingURL=app.js.map
